===============
python-ostinato
===============

python-ostinato provides python bindings for Ostinato.

Ostinato is a network packet/traffic generator and analyzer. It aims to be "Wireshark in Reverse" and become complementary to Wireshark.

Documentation is available in the wiki at http://ostinato.org
